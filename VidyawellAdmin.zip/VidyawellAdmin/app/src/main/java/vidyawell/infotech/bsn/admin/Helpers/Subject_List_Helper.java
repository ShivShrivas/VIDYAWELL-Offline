package vidyawell.infotech.bsn.admin.Helpers;



public class Subject_List_Helper {
    private  String SubjectName="";
    private  String SubjectID="";



    public void setSubjectName(String SubjectName)
    {
        this.SubjectName = SubjectName;
    }
    public String getSubjectName()
    {
        return this.SubjectName;
    }

    public void setSubjectID(String SubjectID)
    {
        this.SubjectID = SubjectID;
    }
    public String getSubjectID()
    {
        return this.SubjectID;
    }
}
