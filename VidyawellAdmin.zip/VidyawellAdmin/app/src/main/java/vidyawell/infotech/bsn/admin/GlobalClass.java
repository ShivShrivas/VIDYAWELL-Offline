package vidyawell.infotech.bsn.admin;

public class GlobalClass {
    public static String Std_List="";
}
