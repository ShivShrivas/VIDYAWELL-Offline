package vidyawell.infotech.bsn.admin.Helpers;



public class Examination_Helper {
    private  String ExamName="";
    private  String Examid="";


    public void setExamid(String Examid)
    {
        this.Examid = Examid;
    }
    public String getExamid()
    {
        return this.Examid;
    }

    public void setExamName(String ExamName)
    {
        this.ExamName = ExamName;
    }
    public String getExamName()
    {
        return this.ExamName;
    }
}
