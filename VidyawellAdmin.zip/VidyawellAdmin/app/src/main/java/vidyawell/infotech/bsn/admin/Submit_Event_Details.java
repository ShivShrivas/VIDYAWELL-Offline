package vidyawell.infotech.bsn.admin;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.room.Room;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import vidyawell.infotech.bsn.admin.Adapters.ImageAdapter;
import vidyawell.infotech.bsn.admin.DAO.UserDao;
import vidyawell.infotech.bsn.admin.Database.RoomDatabaseClass;
import vidyawell.infotech.bsn.admin.Entities.EventIdRelatedPics;
import vidyawell.infotech.bsn.admin.Entities.EventPicture;

public class Submit_Event_Details extends AppCompatActivity {
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.event_images_upload_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id==R.id.event_history){
            Toast.makeText(getApplicationContext(), "Event History Page Panel!!", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);


    }
    LinearLayout layout;
    RecyclerView recyclerView;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private Bitmap mImageBitmap;
    private String mCurrentPhotoPath;
    private ImageView imageView;
    ImageAdapter adapter;
    EditText evenetDesc;
    String eventname;
    RoomDatabaseClass db;
    public static final int RequestPermissionCode = 1;
    public ArrayList<Bitmap> arrayList=new ArrayList<>();
    ArrayList<String> arrayListBitmapAsString=new ArrayList<>();
    UserDao userDao;
    Spinner spinner;
    Button submitEventPicturesBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_event_details);
        getSupportActionBar().setTitle("Submit Event Details");

        db = Room.databaseBuilder(getApplicationContext(),
                RoomDatabaseClass.class, "databse_vidyawell").allowMainThreadQueries().build();
        userDao=db.userDao();
        layout=findViewById(R.id.linearLayoutCamera);
        recyclerView=findViewById(R.id.recyclerViewForShowingPictures);
        imageView=findViewById(R.id.imageView);
        evenetDesc=findViewById(R.id.evenetDesc);
        spinner=findViewById(R.id.spinner_event);
        submitEventPicturesBtn=findViewById(R.id.submitEventPicturesBtn);

        submitEventPicturesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
                String id = sdf.format(new Date());
                EventPicture eventPicture=new EventPicture();
                if (id!=null && eventname!=null){
                    if (evenetDesc.getText().toString().trim()!=null){
                        if (arrayList.size()>0){
                            eventPicture.setEventId(id);
                            eventPicture.setEventName(eventname);
                            eventPicture.setEventDesc(evenetDesc.getText().toString().trim());

                            userDao.insertAll(eventPicture);

                            for (int i=0;i<arrayList.size();i++){

                                EventIdRelatedPics eventIdRelatedPics=new EventIdRelatedPics();
                                eventIdRelatedPics.setEventId(id);
                                eventIdRelatedPics.setEventPictureList(BitMapToString(arrayList.get(i)));
                                userDao.insertAllEventImages(eventIdRelatedPics);
                                Log.d("TAG", "onClick:bitmap images "+arrayList.get(i));
                                Log.d("TAG", "onClick:base 64 images "+BitMapToString(arrayList.get(i)));
                            }

                            Toast.makeText(getApplicationContext(), "Data inserted in database please check!!", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(Submit_Event_Details.this, "Please Capture Atleast One Image", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(Submit_Event_Details.this, "Please Enter Some details About Event", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(getApplicationContext(), "Please Choose an Event...", Toast.LENGTH_SHORT).show();
                }

            }
        });
        ArrayList<String> arrayListSpinner = new ArrayList<>();
        arrayListSpinner.add("Select Event");
        arrayListSpinner.add("Morning Prayer Event");
        arrayListSpinner.add("Lunch Break Event");
        arrayListSpinner.add("Other Event");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, arrayListSpinner);
        arrayAdapter.setDropDownViewResource(R.layout.custom_text_spiner);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                eventname = parent.getItemAtPosition(position).toString();
                Toast.makeText(parent.getContext(), "Selected: " + eventname, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView <?> parent) {
            }
        });
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withContext(Submit_Event_Details.this)
                        .withPermission(Manifest.permission.CAMERA)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                                startActivityForResult(intent, 7);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();
                            }
                        })
                        .check();


            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        adapter= new ImageAdapter(this,arrayList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7 && resultCode == RESULT_OK) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            arrayList.add(bitmap);
        }
    }


    public static String BitMapToString(Bitmap bitmap){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        return Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] result) {
        switch (requestCode) {
            case RequestPermissionCode:
                if (result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Submit_Event_Details.this, "Permission Granted, Now your application can access CAMERA.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Submit_Event_Details.this, "Permission Canceled, Now your application cannot access CAMERA.", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
    }
