package vidyawell.infotech.bsn.admin.Const;



public class AppConst {

    // Location updates intervals
    public static int UPDATE_INTERVAL = 3000; // 3 sec
    public static int FATEST_INTERVAL = 3000; // 5 sec
    public static int DISPLACEMENT = 10; // 10 meters
}
