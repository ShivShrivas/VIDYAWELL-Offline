package vidyawell.infotech.bsn.admin.Helpers;



public class Stream_Helper {
    private  String StreamName="";
    private  String StreamID="";



    public void setStreamName(String StreamName)
    {
        this.StreamName = StreamName;
    }
    public String getStreamName()
    {
        return this.StreamName;
    }

    public void setStreamID(String StreamID)
    {
        this.StreamID = StreamID;
    }
    public String getStreamID()
    {
        return this.StreamID;
    }
}
