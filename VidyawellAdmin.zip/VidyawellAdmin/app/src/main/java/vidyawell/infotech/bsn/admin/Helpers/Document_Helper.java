package vidyawell.infotech.bsn.admin.Helpers;



public class Document_Helper {
    private  String DocumentName="";
    private  String Documentid="";


    public void setDocumentName(String DocumentName)
    {
        this.DocumentName = DocumentName;
    }
    public String getDocumentName()
    {
        return this.DocumentName;
    }

    public void setDocumentid(String Documentid)
    {
        this.Documentid = Documentid;
    }
    public String getDocumentid()
    {
        return this.Documentid;
    }
}
