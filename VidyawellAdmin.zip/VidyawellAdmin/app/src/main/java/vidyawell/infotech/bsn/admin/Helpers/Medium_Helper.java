package vidyawell.infotech.bsn.admin.Helpers;



public class Medium_Helper {
    private  String MediumName="";
    private  String MediumID="";



    public void setMediumName(String MediumName)
    {
        this.MediumName = MediumName;
    }
    public String getMediumName()
    {
        return this.MediumName;
    }

    public void setMediumID(String MediumID)
    {
        this.MediumID = MediumID;
    }
    public String getMediumID()
    {
        return this.MediumID;
    }
}
