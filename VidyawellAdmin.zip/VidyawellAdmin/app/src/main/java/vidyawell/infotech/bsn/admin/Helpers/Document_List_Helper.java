package vidyawell.infotech.bsn.admin.Helpers;



public class Document_List_Helper {
    private  String DocumentName="";
    private  String DocumentID="";



    public void setDocumentName(String DocumentName)
    {
        this.DocumentName = DocumentName;
    }
    public String getDocumentName()
    {
        return this.DocumentName;
    }

    public void setDocumentID(String DocumentID)
    {
        this.DocumentID = DocumentID;
    }
    public String getDocumentID()
    {
        return this.DocumentID;
    }
}
