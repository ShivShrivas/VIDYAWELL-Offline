package vidyawell.infotech.bsn.admin.Helpers;

public class SectionList_Helper {
    private  String SecName="";
    private  String SecID="";



    public void setSecName(String SecName)
    {
        this.SecName = SecName;
    }
    public String getSecName()
    {
        return this.SecName;
    }

    public void setSecID(String SecID)
    {
        this.SecID = SecID;
    }
    public String getSecID()
    {
        return this.SecID;
    }
}
