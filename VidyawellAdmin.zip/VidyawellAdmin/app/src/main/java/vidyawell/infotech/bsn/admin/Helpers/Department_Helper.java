package vidyawell.infotech.bsn.admin.Helpers;



public class Department_Helper {
    private  String DepartName="";
    private  String Departmentid="";


    public void setDepartName(String DepartName)
    {
        this.DepartName = DepartName;
    }
    public String getDepartName()
    {
        return this.DepartName;
    }

    public void setDepartmentid(String Departmentid)
    {
        this.Departmentid = Departmentid;
    }
    public String getDepartmentid()
    {
        return this.Departmentid;
    }
}
