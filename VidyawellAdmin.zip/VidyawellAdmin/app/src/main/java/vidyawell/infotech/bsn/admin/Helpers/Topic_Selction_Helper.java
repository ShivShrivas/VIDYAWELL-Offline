package vidyawell.infotech.bsn.admin.Helpers;

public class Topic_Selction_Helper {
    private  String Topicname="";
    private  String SecID="";



    public void setTopicname(String Topicname)
    {
        this.Topicname = Topicname;
    }
    public String getTopicname()
    {
        return this.Topicname;
    }

    public void setSecID(String SecID)
    {
        this.SecID = SecID;
    }
    public String getSecID()
    {
        return this.SecID;
    }
}
