package vidyawell.infotech.bsn.admin.Helpers;

public class SubjectList_Helper {


    private  String SubId="";
    private  String SubName="";



    public void setSubId(String SubId)
    {
        this.SubId = SubId;
    }
    public String getSubId()
    {
        return this.SubId;
    }

    public void setSubName(String SubName)
    {
        this.SubName = SubName;
    }
    public String getSubName()
    {
        return this.SubName;
    }


}
