package vidyawell.infotech.bsn.admin.Helpers;

/**
 * Created by AmitAIT on 03-11-2018.
 */

public class ClassList_Helper {
    private  String ClassName="";
    private  String ClassID="";



    public void setClassName(String ClassName)
    {
        this.ClassName = ClassName;
    }
    public String getClassName()
    {
        return this.ClassName;
    }

    public void setClassID(String ClassID)
    {
        this.ClassID = ClassID;
    }
    public String getClassID()
    {
        return this.ClassID;
    }
}
