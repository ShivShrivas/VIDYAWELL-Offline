package vidyawell.infotech.bsn.admin.Helpers;

public class Route_Helper {
    public String route_name;
    public String route_time;



    public Route_Helper(String RouteName){
        this.route_name=RouteName;
        this.route_time=route_time;

    }

    public String getRouteName() {
        return route_name;
    }

    public void setRouteName(String RouteName) {
        this. route_name = RouteName;
    }


    public String getroute_time() {
        return route_time;
    }

    public void setroute_time(String route_time) {
        this. route_time = route_time;
    }

}
